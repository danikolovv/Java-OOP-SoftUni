public interface Birthable {
    String getBirthDate();
}
