public interface Rentable {
    Integer getMinRentDay();
    Double getPricePerDay();
}
