package WorkingWithAbstraction.Exercise.P04TrafficLights;

public enum Signals {
    RED,
    GREEN,
    YELLOW;
}
