package WorkingWithAbstraction.Exercise.P01CardSuit;

public enum CardSuit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
